<?php
/**
 * WooCommerce loop start
 *
 * @package Theme Palace
 * @subpackage Yummy
 * @since Yummy 0.1
 */
?>
<ul id="main" class="products gallery-popup col-3">