A Pen created at CodePen.io. You can find this one at https://codepen.io/R4ver/pen/brxzg.

 Because it's too hot to sleep, I decided to make an idea i got while i was trying to sleep.